/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.xemascode.demo;

/**
 *
 * @author kenza ben debba
 */
public class Cinema {
    private int Id;
    private String Nom;
    private int NB_Salles;
    private int NB_Places;
    private String Date_Diffusion;

    public Cinema(int Id, String Nom, int NB_Salles, int NB_Places, String Date_Diffusion) {
        this.Id = Id;
        this.Nom = Nom;
        this.NB_Salles = NB_Salles;
        this.NB_Places = NB_Places;
        this.Date_Diffusion = Date_Diffusion;
    }

    public int getId() {
        return Id;
    }

    public String getNom() {
        return Nom;
    }

    public int getNB_Salles() {
        return NB_Salles;
    }

    public int getNB_Places() {
        return NB_Places;
    }

    public String getDate_Diffusion() {
        return Date_Diffusion;
    }
    
    
}
