/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.xemascode.demo;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author kenza ben debba
 */
public class MainController implements Initializable {
    
  
    @FXML
    private TextField tfId;
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfNB_Salles;
    @FXML
    private TextField tfNB_Places;
    @FXML
    private TextField tfDate_Diffusion;
    @FXML
    private TableView<Cinema> tvCinema;
    @FXML
    private TableColumn<Cinema, Integer> colId;
    @FXML
    private TableColumn<Cinema, String> colNom;
    @FXML
    private TableColumn<Cinema, Integer> colNB_Salles;
    @FXML
    private TableColumn<Cinema, Integer> colNB_Places;
    @FXML
    private TableColumn<Cinema,String> colDate_Diffusion;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnModifier;
    @FXML
    private Button btnSupprimer;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
         if(event.getSource() == btnAjouter){
            insertRecord();
        }else if (event.getSource()== btnModifier){
            updateRecord();
        }else if (event.getSource()== btnSupprimer){
            deleteButton();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       showCinema();
    }    
    
    public Connection getConnection(){
        Connection conn;
        try{ 
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root" , "");
            return conn;
        }catch(SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
            return null;
        }
    }
    public ObservableList<Cinema> getCinemaList(){
        ObservableList<Cinema> cinemaList= FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM cinema";
        Statement st;
        ResultSet rs;
        try {
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Cinema cinema;
            while (rs.next()){
                cinema= new Cinema(rs.getInt("Id"),rs.getString("Nom"),rs.getInt("NB_Salles"),rs.getInt("NB_Places"),rs.getString("Date_Diffusion"));
                cinemaList.add(cinema);
            }
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return cinemaList;
    }
    public void showCinema(){
        ObservableList<Cinema> list  = getCinemaList();
        colId.setCellValueFactory(new PropertyValueFactory <Cinema,Integer>("Id"));
        colNom.setCellValueFactory(new PropertyValueFactory <Cinema,String>("Nom"));
        colNB_Salles.setCellValueFactory(new PropertyValueFactory <Cinema,Integer>("NB_Salles"));
        colNB_Places.setCellValueFactory(new PropertyValueFactory <Cinema,Integer>("NB_Places"));
        colDate_Diffusion.setCellValueFactory(new PropertyValueFactory <Cinema,String>("Date_Diffusion"));
    
        tvCinema.setItems(list);
    }
    
    private void insertRecord(){
        String query = "INSERT INTO cinema VALUES (" + tfId.getText() + ",'" + tfNom.getText() + "','" + tfNB_Salles.getText() + "',"
                + tfNB_Places.getText() + "," + tfDate_Diffusion.getText() + ")";
        executeQuery(query);
        showCinema();
    }
    private void updateRecord(){
        String query = "UPDATE  cinema SET Nom  = '" + tfNom.getText() + "', NB_Salles = '" + tfNB_Salles.getText() + "', NB_Places = " +
                tfNB_Places.getText() + ", Date_Diffusion = " + tfDate_Diffusion.getText() + " WHERE Id = " + tfId.getText() + "";
        executeQuery(query);
        showCinema();
    }
    private void deleteButton(){
        String query = "DELETE FROM cinema WHERE Id =" + tfId.getText() + "";
        executeQuery(query);
        showCinema();
    }

    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }
}
