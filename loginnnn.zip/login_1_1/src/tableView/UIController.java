package tableView;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author kenza ben debba
 */
public class UIController implements Initializable {
@FXML
    private ImageView imageView;
    int count;
    
    @FXML
    private Button btn_GCinema;
    @FXML
    private Button btn_GHome;
    @FXML
    private Button btn_GProjection;
    @FXML
    private Button btn_GBuvette;
    @FXML
    private Button btn_GReservation;
    @FXML
    private Button btn_GInterview;
    @FXML
    private Button btn_GEvenement;
    

       
    
    public void slideshow() {
        ArrayList<Image> images = new ArrayList <Image>();
        images.add(new Image("/2.png"));
        images.add(new Image("/3.jpg"));
        images.add(new Image("/4.jpg"));
        images.add(new Image("/5.jpg"));
        images.add(new Image("/1.jpg"));
        Timeline timeline = new Timeline (new KeyFrame(Duration.seconds(2.5), event -> {
       imageView.setImage(images.get(count));
       count++;
       if(count == 5)
           count = 0;
            
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        
    }
    
    @FXML
    private void GCinema (ActionEvent event) throws Exception{  
    
        try {
            
                JOptionPane.showMessageDialog(null, "welcome to gestion des cinemas");
                
                btn_GCinema.getScene().getWindow().hide();
                Parent root = FXMLLoader.load(getClass().getResource("/tableView/tableView.fxml"));
                Stage mainStage = new Stage();
                Scene scene = new Scene(root);
                mainStage.setScene(scene);
                mainStage.show();
                
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
   
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        slideshow();
    } 

    @FXML
    private void GProjection(ActionEvent event) {
    }

    @FXML
    private void GBuvette(ActionEvent event) {
    }

    @FXML
    private void GReservation(ActionEvent event) {
    }

    @FXML
    private void GInterview(ActionEvent event) {
    }

    @FXML
    private void GEvenement(ActionEvent event) {
    }

    @FXML
    private void GHome(ActionEvent event) {
        
        try {
            
                JOptionPane.showMessageDialog(null, "welcome");
                
                btn_GHome.getScene().getWindow().hide();
                Parent root = FXMLLoader.load(getClass().getResource("/tableView/UI.fxml"));
                Stage mainStage = new Stage();
                Scene scene = new Scene(root);
                mainStage.setScene(scene);
                mainStage.show();
                
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
