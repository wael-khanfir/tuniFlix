/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
//import helpers.DbConnect;
import helpers.mysqlconnect;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import javax.swing.JOptionPane;
import models.Cinema;
import models.Salle;

/**
 * FXML Controller class
 *
 * @author kenza ben debba
 */
public class TableViewController implements Initializable {

    @FXML
    private TableView<Cinema> cinemasTable;
 
     @FXML
    private TableColumn<Cinema,String> nom1Col;
    @FXML
    private TableColumn<Cinema,String> date_creationCol;
    @FXML
    private TableColumn<Cinema,String> adresseCol;
    @FXML
    private TableColumn<Cinema,String> emailCol;
    @FXML
    private TableColumn<Cinema,String> editCol;
    
    
    String query= null;
    Connection connection= null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet= null;
    Cinema cinema = null;
    Salle salle = null;
    
    
    
    
    ObservableList<Cinema> CinemaList = FXCollections.observableArrayList();
    @FXML
    private TextField filterField;
    ObservableList<Cinema> dataList;
    
    @FXML
    private Button btn_GCinema;
    @FXML
    private Button Map;
    
    
    @FXML
    private TableView<Salle> sallesTable;
    
    @FXML
    private TableColumn<Salle,String> nomCol;
    @FXML
    private TableColumn<Salle,String> date_diffusionCol;
    @FXML
    private TableColumn<Salle,String> nb_placesCol;
    @FXML
    private TableColumn<Salle,String> disponibleCol;
    @FXML
    private TableColumn<Salle,String> editCol2;
    
    @FXML
    private AnchorPane pane_GC;
    @FXML
    private AnchorPane pane_GS;
    
    
    
    
    ObservableList<Salle> SalleList = FXCollections.observableArrayList();
    @FXML
    private TextField filterField2;
    ObservableList<Salle> dataList2;
   
    
    
    
     
     
      void search_cinema() {    
   
    nom1Col.setCellValueFactory(new PropertyValueFactory<>("nom")); 
    date_creationCol.setCellValueFactory(new PropertyValueFactory<>("date_creation")); 
    adresseCol.setCellValueFactory(new PropertyValueFactory<>("adresse")); 
    emailCol.setCellValueFactory(new PropertyValueFactory<>("email")); 
        

        dataList = mysqlconnect.getDataCinema(); 
        
       
        cinemasTable.setItems(dataList);
        FilteredList<Cinema> filteredData = new FilteredList<>(dataList, b -> true);  
 filterField.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredData.setPredicate(person -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
    
    if (person.getNom().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches username
    } else if (person.getAdresse().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches password
    }
    else if (String.valueOf(person.getEmail()).indexOf(lowerCaseFilter)!=-1)
         return true;// Filter matches email
                                
         else  
          return false; // Does not match.
   });
  });  
  SortedList<Cinema> sortedData = new SortedList<>(filteredData);  
  sortedData.comparatorProperty().bind(cinemasTable.comparatorProperty());  
  cinemasTable.setItems(sortedData);      
    }
     
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadDateCinema();
        search_cinema();
        
        search_salle();
        loadDateSalles();
    }    

 
    @FXML
    private void getAddViewCinema(MouseEvent event) {
         try {
            Parent parent = FXMLLoader.load(getClass().getResource("/tableView/addCinema.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.initStyle(StageStyle.UTILITY);
            stage.show();
            search_cinema();
            refreshTableCinema();
        } catch (IOException ex) {
            Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    

    @FXML
    private void refreshTableCinema() {
        try {
            CinemaList.clear();
            
            query = "SELECT * FROM `cinema`";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            
            
            while (resultSet.next()) {
                CinemaList.add(new Cinema(
                        resultSet.getInt("id"),
                        resultSet.getString("nom"),
                        resultSet.getDate("date_creation"),
                        resultSet.getString("adresse"),
                        resultSet.getString("email")));
                    cinemasTable.setItems(CinemaList);    
                        }
            search_cinema();
            
        } catch (SQLException ex) {
            Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }


    private void loadDateCinema() {
        
        connection = mysqlconnect.ConnectDb();
         refreshTableCinema();
       
    
    nom1Col.setCellValueFactory(new PropertyValueFactory<>("nom")); 
    date_creationCol.setCellValueFactory(new PropertyValueFactory<>("date_creation")); 
    adresseCol.setCellValueFactory(new PropertyValueFactory<>("adresse")); 
    emailCol.setCellValueFactory(new PropertyValueFactory<>("email")); 
    
     //add cell of button edit 
         Callback<TableColumn<Cinema, String>, TableCell<Cinema, String>> cellFoctory1 = (TableColumn<Cinema, String> param) -> {
            // make cell containing buttons
            final TableCell<Cinema, String> cell = new TableCell<Cinema, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    //that cell created only on non-empty rows
                    if (empty) {
                        setGraphic(null);
                        setText(null);

                    } else {

                        FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
                        FontAwesomeIconView editIcon = new FontAwesomeIconView(FontAwesomeIcon.PENCIL_SQUARE);

                        deleteIcon.setStyle(
                                " -fx-cursor: hand ;"
                                + "-glyph-size:28px;"
                                + "-fx-fill:#ff1744;"
                        );
                        editIcon.setStyle(
                                " -fx-cursor: hand ;"
                                + "-glyph-size:28px;"
                                + "-fx-fill:#00E676;"
                        );
                        deleteIcon.setOnMouseClicked((MouseEvent event) -> {
                             //pour supprimer 
                            Alert alert = new Alert( Alert.AlertType.CONFIRMATION) ;
                            alert.setTitle("Confirmation de suppression  !!");
                            alert.setHeaderText(null);
                            alert.setContentText("Voulez-vous vraiment supprimer ");
                            Optional<ButtonType> action = alert.showAndWait();
                            if ( action.get() == ButtonType.OK) {
                            
                            try {
                                cinema = cinemasTable.getSelectionModel().getSelectedItem();
                                query = "DELETE FROM `cinema` WHERE id  ="+cinema.getId();
                                connection = mysqlconnect.ConnectDb();
                                preparedStatement = connection.prepareStatement(query);
                                preparedStatement.execute();
                                refreshTableCinema();
                                search_cinema();
                                
                            } catch (SQLException ex) {
                                Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            
} //fin supp                         
                        });
                        editIcon.setOnMouseClicked((MouseEvent event) -> {
                            
                            cinema = cinemasTable.getSelectionModel().getSelectedItem();
                            FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("/tableView/addCinema.fxml"));
                            try {
                                loader.load();
                            } catch (IOException ex) {
                                Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            AddCinemaController addCinemaController = loader.getController();
                            addCinemaController.setUpdate(true);
                            addCinemaController.setTextField(cinema.getId(), cinema.getNom(), 
                                    cinema.getDate_creation().toLocalDate(),cinema.getAdresse(), cinema.getEmail());
                            Parent parent = loader.getRoot();
                            Stage stage = new Stage();
                            stage.setScene(new Scene(parent));
                            stage.initStyle(StageStyle.UTILITY);
                            stage.show();
                           
                            search_cinema();
                            

                           

                        });

                        HBox managebtn = new HBox(editIcon, deleteIcon);
                        managebtn.setStyle("-fx-alignment:center");
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(managebtn);

                        setText(null);

                    }
                }

            };

            return cell;
        };
         editCol.setCellFactory(cellFoctory1);
         cinemasTable.setItems(CinemaList);
         
    
    }

    @FXML
    private void MapMousePressed(ActionEvent event) throws Exception {
        Map mp = new Map();
try {
mp.setVisible(true);
} catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        
    }
    
}


    @FXML
    private void GCpaneShow(ActionEvent event) {
        pane_GC.setVisible(true);
        pane_GS.setVisible(false);
    }

    @FXML
    private void GSpaneShow(ActionEvent event) {
        pane_GC.setVisible(false);
        pane_GS.setVisible(true);
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
 //2eme table  Gestion salles 
    
    void search_salle() {    
    
    nomCol.setCellValueFactory(new PropertyValueFactory<>("nom")); 
    date_diffusionCol.setCellValueFactory(new PropertyValueFactory<>("date_diffusion")); 
    nb_placesCol.setCellValueFactory(new PropertyValueFactory<>("nb_places")); 
    disponibleCol.setCellValueFactory(new PropertyValueFactory<>("disponible")); 
        

        dataList2 = mysqlconnect.getDataSalle(); 
       
        sallesTable.setItems(dataList2);
        FilteredList<Salle> filteredData2 = new FilteredList<>(dataList2, b -> true);  
 filterField2.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredData2.setPredicate(person -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter2 = newValue.toLowerCase();
    //recherche
    if (person.getNom().toLowerCase().indexOf(lowerCaseFilter2) != -1 ) {
     return true; // Filter matches username
    } else if (person.getNb_places().toLowerCase().indexOf(lowerCaseFilter2) != -1) {
     return true; // Filter matches password
    }
    else if (String.valueOf(person.getDisponible()).indexOf(lowerCaseFilter2)!=-1)
         return true;// Filter matches disponible
                                
         else  
          return false; // Does not match.
   });
  });  
  SortedList<Salle> sortedData2 = new SortedList<>(filteredData2);  
  sortedData2.comparatorProperty().bind(sallesTable.comparatorProperty());  
  sallesTable.setItems(sortedData2);      
    }
    
    
    @FXML
    private void getAddViewSalles(MouseEvent event) {
         try {
            Parent parent = FXMLLoader.load(getClass().getResource("/tableView/addSalle.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.initStyle(StageStyle.UTILITY);
            stage.show();
            search_salle();
        } catch (IOException ex) {
            Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);//getName() ?
        }
    }
    
    @FXML
    private void refreshTableSalles() {
        try {
            SalleList.clear();
            
            query = "SELECT * FROM `salle`";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            
            
            while (resultSet.next()) {
                SalleList.add(new Salle(
                        resultSet.getInt("id"),
                        resultSet.getString("nom"),
                        resultSet.getDate("date_diffusion"),
                        resultSet.getString("nb_places"),
                        resultSet.getString("disponible")));
                    sallesTable.setItems(SalleList);    
                        }
            search_salle();
            
        } catch (SQLException ex) {
            Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void loadDateSalles() {
        
        connection = mysqlconnect.ConnectDb();
         refreshTableSalles();
       
    
    nomCol.setCellValueFactory(new PropertyValueFactory<>("nom")); 
    date_diffusionCol.setCellValueFactory(new PropertyValueFactory<>("date_diffusion")); 
    nb_placesCol.setCellValueFactory(new PropertyValueFactory<>("nb_places")); 
    disponibleCol.setCellValueFactory(new PropertyValueFactory<>("disponible")); 
    
     //add cell of button edit 
         Callback<TableColumn<Salle, String>, TableCell<Salle, String>> cellFoctory2 = (TableColumn<Salle, String> param) -> {
            // make cell containing buttons
            final TableCell<Salle, String> cell = new TableCell<Salle, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    //that cell created only on non-empty rows
                    if (empty) {
                        setGraphic(null);
                        setText(null);

                    } else {

                        FontAwesomeIconView deleteIcon = new FontAwesomeIconView(FontAwesomeIcon.TRASH);
                        FontAwesomeIconView editIcon = new FontAwesomeIconView(FontAwesomeIcon.PENCIL_SQUARE);

                        deleteIcon.setStyle(
                                " -fx-cursor: hand ;"
                                + "-glyph-size:28px;"
                                + "-fx-fill:#ff1744;"
                        );
                        editIcon.setStyle(
                                " -fx-cursor: hand ;"
                                + "-glyph-size:28px;"
                                + "-fx-fill:#00E676;"
                        );
                        deleteIcon.setOnMouseClicked((MouseEvent event) -> {
                             //pour supprimer 
                            Alert alert = new Alert( Alert.AlertType.CONFIRMATION) ;
                            alert.setTitle("Confirmation de suppression  !!");
                            alert.setHeaderText(null);
                            alert.setContentText("Voulez-vous vraiment supprimer ");
                            Optional<ButtonType> action = alert.showAndWait();
                            if ( action.get() == ButtonType.OK) {
                            
                            try {
                                salle = sallesTable.getSelectionModel().getSelectedItem();
                                query = "DELETE FROM `salle` WHERE id  ="+salle.getId();
                                connection = mysqlconnect.ConnectDb();
                                preparedStatement = connection.prepareStatement(query);
                                preparedStatement.execute();
                                refreshTableSalles();
                                search_salle();
                                
                            } catch (SQLException ex) {
                                Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex); //getName()?
                            }
                            
                            
} //fin supp                         
                        });
                        editIcon.setOnMouseClicked((MouseEvent event) -> {
                            
                            salle = sallesTable.getSelectionModel().getSelectedItem();
                            FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("/tableView/addSalle.fxml"));
                            try {
                                loader.load();
                            } catch (IOException ex) {
                                Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            AddSalleController addSalleController = loader.getController();
                            addSalleController.setUpdate(true);
                            addSalleController.setTextField(salle.getId(), salle.getNom(), 
                                    salle.getDate_diffusion().toLocalDate(),salle.getNb_places(), salle.getDisponible());
                            Parent parent = loader.getRoot();
                            Stage stage = new Stage();
                            stage.setScene(new Scene(parent));
                            stage.initStyle(StageStyle.UTILITY);
                            stage.show();
                            search_salle();
                            

                           

                        });

                        HBox managebtn = new HBox(editIcon, deleteIcon);
                        managebtn.setStyle("-fx-alignment:center");
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(managebtn);

                        setText(null);

                    }
                }

            };

            return cell;
        };
         editCol2.setCellFactory(cellFoctory2);
         sallesTable.setItems(SalleList);
         
    
    }

   
    
}
