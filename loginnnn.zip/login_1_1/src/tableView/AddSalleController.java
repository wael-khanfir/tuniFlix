/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import helpers.mysqlconnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import models.Salle;

/**
 * FXML Controller class
 *
 * @author kenza ben debba
 */
public class AddSalleController implements Initializable {

    @FXML
    private TextField nomFId;
    @FXML
    private DatePicker date_diffusionFId;
    @FXML
    private TextField nb_placesFId;
    @FXML
    private ComboBox disponibleFId;
    
    String query= null;
    Connection connection= null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet= null;
    Salle salle = null;
    
    private boolean update;
    int salleId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        disponibleFId.getItems().addAll("oui","non");
    }    

    @FXML
    private void save(MouseEvent event) {
        
         connection = mysqlconnect.ConnectDb();
        String nom = nomFId.getText();
        String date_diffusion = String.valueOf(date_diffusionFId.getValue());
        String nb_places = nb_placesFId.getText();
        String disponible = disponibleFId.getValue().toString();

        if (nom.isEmpty() || date_diffusion.isEmpty() || nb_places.isEmpty() || disponible.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Fill All DATA");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();

        }
        
    }

    @FXML
    private void clean() {
         nomFId.setText(null);
        date_diffusionFId.setValue(null);
        nb_placesFId.setText(null);
        disponibleFId.setValue(null);
    }

    private void getQuery() {
        if(update ==false) {
       
            query = "INSERT INTO `salle`(`nom`, `date_diffusion`, `nb_places`, `disponible`) VALUES (?,?,?,?)";
 
        }else {
            query = "UPDATE `salle` SET "
                    + "`nom`=?,"
                    + "`date_diffusion`=?,"
                    + "`nb_places`=?,"
                    + "`disponible`= ? WHERE id = '"+salleId+"'";
        }
    }
    
  

    private void insert() {
        
       
          try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nomFId.getText());
            preparedStatement.setString(2, String.valueOf(date_diffusionFId.getValue()));
            preparedStatement.setString(3, nb_placesFId.getText());
            preparedStatement.setString(4, disponibleFId.getValue().toString());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddSalleController.class.getName()).log(Level.SEVERE, null, ex); //getName()?
        }
        
    }

    void setUpdate(boolean b) {
         this.update = b;
    }

    void setTextField(int id, String nom, LocalDate toLocalDate, String nb_places, String disponible) {
     salleId = id;
        nomFId.setText(nom);
        date_diffusionFId.setValue(toLocalDate);
        nb_placesFId.setText(nb_places);
        disponibleFId.setValue(disponible);
    }
    
    
 
    
}
