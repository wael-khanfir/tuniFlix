/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author kenza ben debba
 */
public class FrontController implements Initializable {
    @FXML
    private ImageView imageView;
   
    int count, count2;
    @FXML
    private Button btn_Home;
    @FXML
    private Button btn_sauthentifier;
    
    @FXML
    private Button btn_Home1;
    @FXML
    private Button btn_Home2;
    @FXML
    private Button btn_Home3;
    @FXML
    private Button btn_Home4;

    
    
    public void slideshow() {
        ArrayList<Image> images = new ArrayList <Image>();
        images.add(new Image("/2.png"));
        images.add(new Image("/3.jpg"));
        images.add(new Image("/4.jpg"));
        images.add(new Image("/5.jpg"));
        images.add(new Image("/1.jpg"));
        Timeline timeline = new Timeline (new KeyFrame(Duration.seconds(2.5), event -> {
       imageView.setImage(images.get(count));
       count++;
       if(count == 5)
           count = 0;
            
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        
    }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        slideshow();
  
    }    

    @FXML
    private void GHome(ActionEvent event) {
        try {
            
                JOptionPane.showMessageDialog(null, "welcome ");
                
                btn_Home.getScene().getWindow().hide();
                Parent root = FXMLLoader.load(getClass().getResource("/tableView/Front.fxml"));
                Stage mainStage = new Stage();
                Scene scene = new Scene(root);
                mainStage.setScene(scene);
                mainStage.show();
                
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @FXML
    private void sauthentifier(ActionEvent event) {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("/tableView/login.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.initStyle(StageStyle.UTILITY);
            stage.show();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }
   
}
