/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.Date;

/**
 *
 * @author kenza ben debba
 */
public class Salle {
    int id;
    String nom;
    Date date_diffusion;
    String nb_places, disponible;

    public Salle(int id, String nom, Date date_diffusion, String nb_places, String disponible) {
        this.id = id;
        this.nom = nom;
        this.date_diffusion = date_diffusion;
        this.nb_places = nb_places;
        this.disponible = disponible;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getDate_diffusion() {
        return date_diffusion;
    }

    public void setDate_diffusion(Date date_diffusion) {
        this.date_diffusion = date_diffusion;
    }

    public String getNb_places() {
        return nb_places;
    }

    public void setNb_places(String nb_places) {
        this.nb_places = nb_places;
    }

    public String getDisponible() {
        return disponible;
    }

    public void setDisponible(String disponible) {
        this.disponible = disponible;
    }
    
    
}
