package helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import models.Cinema;
import models.Salle;

/**
 *
 * @author amir
 */
public class mysqlconnect {
    Connection conn = null;
    public static Connection ConnectDb(){
 
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/pidev","root","");
       //     JOptionPane.showMessageDialog(null, "Connection Established");
            return conn;
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            Logger.getLogger(mysqlconnect.class.getName()).log(Level.SEVERE, null, e);
            return null;
        } 
    }
//pour recherche    
    public static ObservableList<Cinema> getDataCinema(){
        Connection conn = ConnectDb();
        ObservableList<Cinema> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from cinema");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new Cinema(Integer.parseInt(rs.getString("id")), rs.getString("nom"), rs.getDate("date_creation"), rs.getString("adresse"), rs.getString("email")));               
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    public static ObservableList<Salle> getDataSalle(){
        Connection conn = ConnectDb();
        ObservableList<Salle> list2 = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from salle");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list2.add(new Salle(Integer.parseInt(rs.getString("id")), rs.getString("nom"), rs.getDate("date_diffusion"), rs.getString("nb_places"), rs.getString("disponible")));               
            }
        } catch (Exception e) {
        }
        return list2;
    }

}
